function submitForm() {
    const firstname = document.forms.loginform.firstname.value;
    const lastname = document.forms.loginform.lastname.value;
    const age = document.forms.loginform.age.value;
    const gender = document.forms.loginform.gender.value;
    const address = document.forms.loginform.address.value;
     
    
    let text = "Hi " + firstname + " " + lastname + " aged " + age + " who is a " + gender + " and lives in " + address;
    document.write(text);
  }
